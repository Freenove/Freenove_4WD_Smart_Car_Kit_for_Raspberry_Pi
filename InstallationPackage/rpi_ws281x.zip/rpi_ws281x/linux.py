
import SCons
import string
import array
import os


tools = ['gcc', 'g++', 'gnulink', 'ar', 'gas']


def linux_tools(env):
    for tool in tools:
        env.Tool(tool)

    if not env['V']:
        env['ARCOMSTR']      = 'AR      ${TARGET}'
        env['ASCOMSTR']      = 'AS      ${TARGET}'
        env['CCCOMSTR']      = 'CC      ${TARGET}'
        env['CXXCOMSTR']     = 'C++     ${TARGET}'
        env['LINKCOMSTR']    = 'LINK    ${TARGET}'
        env['RANLIBCOMSTR']  = 'RANLIB  ${TARGET}'

def linux_flags(env):
    env.MergeFlags({
        'CPPFLAGS' : '''
            -fPIC
            -g
            -O2
            -Wall
            -Wextra
            -Werror
        '''.split(),
    }),
    env.MergeFlags({
        'LINKFLAGS' : '''
        '''.split()
    })


def linux_builders(env):
    env.Append(BUILDERS = {
        'Program' : SCons.Builder.Builder(
            action = SCons.Action.Action('${LINK} -o ${TARGET} ${SOURCES} ${LINKFLAGS}',
                                         '${LINKCOMSTR}'),
        ),
    })
    return 1


# The following are required functions by SCons when incorporating through tools
def exists(env):
    return 1

def generate(env, **kwargs):
    [f(env) for f in (linux_tools, linux_flags, linux_builders)]

