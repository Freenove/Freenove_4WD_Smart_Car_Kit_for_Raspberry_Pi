#include <stdint.h>

#include "ws2811.h"

#include "pwm.h"


// Mapping of Pin to alternate function for PWM channel 0
const pwm_pin_table_t pwm_pin_chan0[] =
{
    {
        .pinnum = 12,
        .altnum = 0,
    },
    {
        .pinnum = 18,
        .altnum = 5,
    },
    {
        .pinnum = 40,
        .altnum = 0,
    },
};

// Mapping of Pin to alternate function for PWM channel 1
const pwm_pin_table_t pwm_pin_chan1[] =
{
    {
        .pinnum = 13,
        .altnum = 0,
    },
    {
        .pinnum = 19,
        .altnum = 5,
    },
    {
        .pinnum = 41,
        .altnum = 0,
    },
    {
        .pinnum = 45,
        .altnum = 0,
    },
};

const pwm_pin_tables_t pwm_pin_tables[RPI_PWM_CHANNELS] =
{
    {
        .pins = pwm_pin_chan0,
        .count = sizeof(pwm_pin_chan0) / sizeof(pwm_pin_chan0[0]),
    },
    {
        .pins = pwm_pin_chan1,
        .count = sizeof(pwm_pin_chan1) / sizeof(pwm_pin_chan1[0]),
    },
};


int pwm_pin_alt(int chan, int pinnum)
{
    const pwm_pin_tables_t *pintable = &pwm_pin_tables[chan];
    int i;

    for (i = 0; i < pintable->count; i++)
    {
        if (pintable->pins[i].pinnum == pinnum)
        {
            return pintable->pins[i].altnum;
        }
    }

    return -1;
}

