

import SCons, os

def version_flags(env):
    if not env['V']:
        env['VERSIONCOMSTR'] = 'Version ${TARGET}'

def version_builders(env):
    def generate_version_header(target, source, env):
        headername = os.path.basename(target[0].abspath)
        headerdef = headername.replace('.', '_').replace('-', '_').upper()

        try:
            version = open(source[0].abspath, 'r').readline().strip().split('.')
        except:
            version = [ '0', '0', '0' ]

        f = open(headername, 'w')
        f.write('/* Auto Generated Header built by version.py - DO NOT MODIFY */\n')
        f.write('\n')
        f.write('#ifndef __%s__\n' % (headerdef))
        f.write('#define __%s__\n' % (headerdef))
        f.write('\n')
        f.write('#define VERSION_MAJOR %s\n' % version[0])
        f.write('#define VERSION_MINOR %s\n' % version[1])
        f.write('#define VERSION_MICRO %s\n' % version[2])
        f.write('\n')
        f.write('#endif /* __%s__ */\n' % (headerdef))
        f.close()

    env.Append(BUILDERS = {
        'Version' : SCons.Builder.Builder(
            action = SCons.Action.Action(generate_version_header, '${VERSIONCOMSTR}'),
            suffix = '.h',
        ),
    })

def exists(env):
    return 1

def generate(env, **kwargs):
    [f(env) for f in (version_flags, version_builders)]


